"""Predefined clinical thresholds (general reference ranges, not medical advice)."""

THRESHOLDS = {
    "systolic_bp":  {"label": "Systolic BP",  "unit": "mmHg", "low": 90,   "high": 140},
    "diastolic_bp": {"label": "Diastolic BP", "unit": "mmHg", "low": 60,   "high": 90},
    "heart_rate":   {"label": "Heart Rate",   "unit": "bpm",  "low": 50,   "high": 100},
    "glucose":      {"label": "Blood Glucose","unit": "mg/dL","low": 70,   "high": 126},
    "spo2":         {"label": "SpO2",         "unit": "%",    "low": 92,   "high": 100},
    "temperature":  {"label": "Temperature",  "unit": "°C",   "low": 35.5, "high": 38.0},
}
