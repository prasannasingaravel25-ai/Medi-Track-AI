import json
from pathlib import Path
from flask import Flask, jsonify, request, Response, send_from_directory
from flask_cors import CORS

from analysis import check_alerts, analyze_history
from report import build_report_html
from thresholds import THRESHOLDS

BASE = Path(__file__).resolve().parent.parent
DATA_FILE = BASE / "data" / "sample_readings.json"

app = Flask(__name__, static_folder=str(BASE / "frontend"), static_url_path="")
CORS(app)


def load():
    return json.loads(DATA_FILE.read_text())


def save(readings):
    DATA_FILE.write_text(json.dumps(readings, indent=2))


@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.get("/api/thresholds")
def thresholds():
    return jsonify(THRESHOLDS)


@app.get("/api/readings")
def get_readings():
    return jsonify(load())


@app.post("/api/readings")
def add_reading():
    reading = request.get_json(force=True)
    readings = load()
    readings.append(reading)
    save(readings)
    return jsonify({"saved": True, "alerts": check_alerts(reading)}), 201


@app.get("/api/analysis")
def analysis():
    readings = load()
    all_alerts = []
    for r in readings:
        for a in check_alerts(r):
            all_alerts.append({**a, "date": r.get("date")})
    return jsonify({"summary": analyze_history(readings), "alerts": all_alerts})


@app.get("/api/report")
def report():
    readings = load()
    summary = analyze_history(readings)
    alerts = [a for r in readings[-3:] for a in check_alerts(r)]
    return Response(build_report_html(readings, summary, alerts), mimetype="text/html")


if __name__ == "__main__":
    app.run(debug=True, port=5000)
