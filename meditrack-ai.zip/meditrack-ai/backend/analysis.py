from thresholds import THRESHOLDS


def check_alerts(reading):
    """Return a list of alerts for one reading that crosses a threshold."""
    alerts = []
    for key, rule in THRESHOLDS.items():
        value = reading.get(key)
        if value is None:
            continue
        if value > rule["high"]:
            alerts.append({"metric": rule["label"], "value": value, "level": "HIGH",
                           "message": f'{rule["label"]} {value} {rule["unit"]} is above {rule["high"]}'})
        elif value < rule["low"]:
            alerts.append({"metric": rule["label"], "value": value, "level": "LOW",
                           "message": f'{rule["label"]} {value} {rule["unit"]} is below {rule["low"]}'})
    return alerts


def trend(values):
    """Simple linear-regression slope -> rising / falling / stable."""
    n = len(values)
    if n < 3:
        return "not enough data"
    xs = list(range(n))
    mx, my = sum(xs) / n, sum(values) / n
    den = sum((x - mx) ** 2 for x in xs)
    slope = sum((x - mx) * (y - my) for x, y in zip(xs, values)) / den
    pct = abs(slope) / (my or 1) * 100  # % change per reading
    if pct < 0.5:
        return "stable"
    return "rising" if slope > 0 else "falling"


def analyze_history(readings):
    """Trend per metric across the whole history."""
    out = {}
    for key, rule in THRESHOLDS.items():
        vals = [r[key] for r in readings if r.get(key) is not None]
        if vals:
            out[key] = {"label": rule["label"], "latest": vals[-1],
                        "average": round(sum(vals) / len(vals), 1),
                        "trend": trend(vals)}
    return out
