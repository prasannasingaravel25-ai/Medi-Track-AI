from datetime import datetime


def build_report_html(readings, summary, alerts):
    rows = "".join(
        f"<tr><td>{v['label']}</td><td>{v['latest']}</td><td>{v['average']}</td><td>{v['trend']}</td></tr>"
        for v in summary.values()
    )
    alert_items = "".join(f"<li>[{a['level']}] {a['message']}</li>" for a in alerts) or "<li>No alerts.</li>"
    return f"""<html><head><title>MediTrack AI Report</title>
<style>body{{font-family:Arial;margin:40px}}table{{border-collapse:collapse;width:100%}}
td,th{{border:1px solid #ccc;padding:8px;text-align:left}}th{{background:#0b6e8a;color:#fff}}</style></head>
<body><h1>MediTrack AI – Health Report</h1>
<p>Generated: {datetime.now():%Y-%m-%d %H:%M} | Readings analysed: {len(readings)}</p>
<h2>Summary</h2><table><tr><th>Metric</th><th>Latest</th><th>Average</th><th>Trend</th></tr>{rows}</table>
<h2>Alerts</h2><ul>{alert_items}</ul>
<p><i>This report is informational only and not a medical diagnosis. Please consult a healthcare professional.</i></p>
</body></html>"""
