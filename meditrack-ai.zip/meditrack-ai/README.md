# MediTrack AI – Smart Health Monitoring System

AI-powered health monitoring that tracks measurements, analyzes historical data, shows interactive dashboards,
raises alerts when readings cross predefined clinical thresholds, and generates digital health reports —
supporting preventive healthcare and timely professional medical guidance.

## Features
- Record health readings (BP, heart rate, glucose, SpO2, temperature)
- Trend analysis across historical data (rising / falling / stable)
- Threshold-based alerts
- Interactive dashboard (Chart.js)
- Printable digital health report

## Project Structure
```
meditrack-ai/
├── backend/    # Flask API (app.py, analysis.py, thresholds.py, report.py)
├── frontend/   # Dashboard (index.html, style.css, app.js)
├── data/       # Sample readings (JSON)
├── docs/       # Slides, screenshots, notes
├── requirements.txt
└── README.md
```

## Run Locally
```bash
pip install -r requirements.txt
cd backend
python app.py
```
Open http://localhost:5000

## Disclaimer
Informational only. Not a medical diagnosis or substitute for professional medical advice.

## Team
Hack for Social Cause (HSC) – add team members here.
