const API = "/api";
let thresholds = {}, readings = [], chart;

async function init() {
  thresholds = await (await fetch(`${API}/thresholds`)).json();
  const form = document.getElementById("form");
  const sel = document.getElementById("metric");
  form.innerHTML = `<input type="date" id="date" value="${new Date().toISOString().slice(0,10)}">`;
  for (const [key, t] of Object.entries(thresholds)) {
    form.innerHTML += `<input type="number" step="0.1" id="${key}" placeholder="${t.label} (${t.unit})">`;
    sel.innerHTML += `<option value="${key}">${t.label}</option>`;
  }
  sel.onchange = drawChart;
  document.getElementById("save").onclick = saveReading;
  refresh();
}

async function saveReading() {
  const r = { date: document.getElementById("date").value };
  for (const key of Object.keys(thresholds)) {
    const v = document.getElementById(key).value;
    if (v !== "") r[key] = parseFloat(v);
  }
  await fetch(`${API}/readings`, { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify(r) });
  refresh();
}

async function refresh() {
  readings = await (await fetch(`${API}/readings`)).json();
  const a = await (await fetch(`${API}/analysis`)).json();
  document.getElementById("alerts").innerHTML = a.alerts.length
    ? a.alerts.slice(-8).reverse().map(x => `<li class="alert-${x.level}">${x.date}: ${x.message}</li>`).join("")
    : "<li>No alerts</li>";
  document.getElementById("summary").innerHTML = Object.values(a.summary)
    .map(s => `<p><b>${s.label}</b>: latest ${s.latest}, avg ${s.average}, trend <i>${s.trend}</i></p>`).join("");
  drawChart();
}

function drawChart() {
  const key = document.getElementById("metric").value;
  const t = thresholds[key];
  const pts = readings.filter(r => r[key] !== undefined);
  const labels = pts.map(r => r.date);
  if (chart) chart.destroy();
  chart = new Chart(document.getElementById("chart"), {
    type: "line",
    data: { labels, datasets: [
      { label: t.label, data: pts.map(r => r[key]), borderColor: "#0b6e8a", tension: .25 },
      { label: "High limit", data: labels.map(() => t.high), borderColor: "#c0392b", borderDash: [6,4], pointRadius: 0 },
      { label: "Low limit",  data: labels.map(() => t.low),  borderColor: "#d68910", borderDash: [6,4], pointRadius: 0 }
    ]}
  });
}
init();
